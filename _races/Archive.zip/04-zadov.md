---
raceid: zadov
name: Zadov
date: 10.6.2018
day: Neděle
place: Zadov Churáňov
organizator_name: Česká unie sportu, Bike klub Vimperk		
organizator_url: http://www.cs-mtb.cz
race_director: Vojtěch Huřík
race_director_phone: 607-108-362
chief_commisaire: Robert Skála
registration_link: http://jcp-mtb.sportsoft.cz/events.aspx
image_url: "assets/img/zadov-promo.png"
square_image_url: "assets/img/zadov-promo-square.png"
sportsoft_timekeeping: true
propositions_url: https://docs.google.com/document/d/14miyb_2Mb2lEGqyhDzSWTxXwnJtv3EF7HqM7pR3B-iM/edit?usp=sharing
poster_url: "assets/SP-ZADOV-2018.pdf"
results_link: http://sportsoft.cz/OfficialResults/2018/20180610_sp_zadov_vse.pdf?201806.10.03.01
---
Třetí závod Šumavského poháru MTB 2018 se jede zároveň jako **Přebor Jihočeského svazu cyklistiky MTB XCO**. Závod se koná týden před závodem ČP MTB na Zadově. Účastníci tak mají ideální příležitost vyzkoušet si části pohárové tratě v závodním tempu.
