---
raceid: horni-plana
name: Horní Planá
date: 20.5.2018
day: Neděle
place: Horní Planá
organizator_name: Obec Horní Planá
organizator_url: https://www.horniplana.cz
#organizator_email: lykoklub@seznam.cz
race_director: Jiří Mánek
#race_director_phone: (0176) 435 199 28
#race_director_email: info@rscwaldkirchen.de
chief_commisaire: Jiří Mánek
#course_director: nil
#medical_assistantce: HS Šumava
#race_id: nil
registration_link: http://jcp-mtb.sportsoft.cz/events.aspx
#results_link: nil
image_url: "assets/img/horni-plana-promo.png"
square_image_url: "assets/img/horni-plana-promo-square.png"
sportsoft_timekeeping: true
propositions_url: https://docs.google.com/document/d/1SEBYlZi6Ick_PlWyr676OARedbvYUiQ8bttNK0SnsjE/edit?usp=sharing
poster_url: "assets/img/horni-plana-poster.png"
results_link: http://sportsoft.cz/OfficialResults/2018/20180520_jcp_horni_plana_KAT.pdf?201805.20.03.13
---

Po loňské úspěšné obnovené premiéře se Šumavský pohár MTB vrací do Horní Plané i v roce 2018. Tratě budou opět situovány na starém hřišti za hřbitovem u kostela Pany Marie Bolestné. Možnost parkování na loukách v blízkosti prostoru statu a cíle (bude vyznačeno). Detailní informace a aktuální inofrmace o závodě můžete nalézt na [oficiálních stránkách závodu](http://www.lipensko.cz/akce/zavod-na-horskych-kolech-vktt1q0kvf).
