---
raceid: talin
name: Kukle - Tálín
date: 24.6.2018
day: Neděle
place: Kukle - Tálín
organizator_name: Biketime Bulls Písek
organizator_url: http://www.btbpisek.cz/
organizator_email: truhlarstvihronek@seznam.cz
race_director: Jaroslav Hronek
# race_director_phone: ---
# race_director_email: info@rscwaldkirchen.de
chief_commisaire: ---
# course_director: Jan Jedlička
# medical_assistantce: HS Zadov
# race_id: nil
registration_link: http://jcp-mtb.sportsoft.cz/events.aspx
results_link: http://sportsoft.cz/OfficialResults/2018/20180624_sp_talin_komplet.pdf?201806.24.02.58
image_url: "assets/img/talin-promo.jpg"
square_image_url: "assets/img/talin-promo-square.png"
sportsoft_timekeeping: true
propositions_url: https://docs.google.com/document/d/1E8lJ2-l4D51awBBpkMjhBJ2i6SS-Tp1qTpfFOX07dbQ/edit?usp=sharing
---

Čtvrtý závod Šumavského poháru MTB 2018. Závod v Tálíně je novinkou v letošním seriálu. Pořadatelé z [Biketime Bulls Písek](http://www.btbpisek.cz/) mají bohaté zkušenosti s pořádání tradičního maratónu v Tálíně, i s pořádáním dětských závodů, takže se máme rozhodně na co těšit.
