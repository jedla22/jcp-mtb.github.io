---
raceid: prachatice
name: Prachatice
date: 14.7.2018
day: Sobota
place: Prachatice – areál DM SPgŠ Prachatice Zlatá stezka 139 Prachatice
organizator_name: LYKO klub Prachatice
organizator_url: http://www.lykoklub.cz
organizator_email: lykoklub@seznam.cz
race_director: Václav Dostál
# race_director_phone: ---
# race_director_email: info@rscwaldkirchen.de
chief_commisaire: Bohumil Šísl
# course_director: Jan Jedlička
medical_assistantce: ZS Prachatice
# race_id: nil
registration_link: http://jcp-mtb.sportsoft.cz/events.aspx
results_link: https://sportsoft.cz/OfficialResults/2018/Report.pdf?201807.14.02.30
image_url: "assets/img/prachatice-promo.jpg"
square_image_url: "assets/img/prachatice-promo-square.png"
sportsoft_timekeeping: true
propositions_url: https://docs.google.com/document/d/1lmNSbMA-63mi-Nb2kzJ0Z884T8DRQD_gwDuV_AsdJ2Q/edit?usp=sharing
---

Závod je finálovým závodem Šumavského poháru MTB 2017. Závodníci tak mají poslední možnost získat body do celkového hodnocení poháru. Součástí závodu je i **vyhlášení celkových výsledků Šumavského poháru MTB 2018**, které proběhne na závěr, po vyhlášení výsledků finálového závodu.
