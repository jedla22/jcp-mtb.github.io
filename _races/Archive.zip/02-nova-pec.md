---
raceid: nova-pec
name: Nová Pec
date: 13.5.2018
day: Neděle
place: Nová Pec (Lipno)
organizator_name: LYKO klub Prachatice
organizator_url: http://www.lykoklub.cz
organizator_email: lykoklub@seznam.cz
race_director: Václav Dostál
#race_director_phone: (0176) 435 199 28
#race_director_email: info@rscwaldkirchen.de
chief_commisaire: Václav Dostál
#course_director: nil
medical_assistantce: HS Šumava
#race_id: nil
registration_link: http://jcp-mtb.sportsoft.cz/events.aspx
#results_link: nil
image_url: "assets/img/nova-pec-promo.jpg"
square_image_url: "assets/img/nova-pec-promo-square.png"
sportsoft_timekeeping: true
propositions_url: https://docs.google.com/document/d/1ve0vWtmi4DKo5KhKbwGTKAPR2JDPgWzWIwFcneG3Ufw/edit?usp=sharing
results_link: http://sportsoft.cz/de/race/results/2472?rid=2847
---

Druhý závod Šumavského poháru MTB 2018 se koná v tradiční lokalitě v Nové Peci. Tratě připravené pořadatelským týmem [LYKO klubu Prachatice](http://www.lykoklub.cz/) jsou vytyčeny v okolí chatového tábora v Nové Peci.   
