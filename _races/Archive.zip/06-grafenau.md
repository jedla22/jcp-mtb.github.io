---
raceid: grafenau
name: Grafenau
date: 1.7.2018
day: Neděle
place: Grafenau
organizator_name: RSV Grafenau
organizator_url: http://www.rsv-grafenau.de/
# organizator_email: lykoklub@seznam.cz
race_director: ---
# race_director_phone: ---
# race_director_email: info@rscwaldkirchen.de
chief_commisaire: ---
# race_id: nil
registration_link: https://docs.google.com/forms/d/e/1FAIpQLSd-hvuV11H2hf0EogEgmfS3ggtv-NqQ7hFz4XG7-nXW8KrDgA/viewform
results_link: http://www.timebike.de/SPK-MTB/Ergebnisse/2018/CC_Grafenau.pdf
image_url: "assets/img/grafenau-promo.jpg"
square_image_url: "assets/img/grafenau-promo-square.png"
# sportsoft_timekeeping: true
propositions_url: http://sportsoft.cz/OfficialResults/2018/20180624_sp_talin_komplet.pdf?201806.24.02.58

---

Pátý závod Šumavského poháru MTB 2018. Závod je součástí partnerského seriálu [Sparkassen MTB Cup](www.spk-mtb.de/). Závodí se podle pravidel seriálu *Sparkassen MTB Cup*, viz propozice.
