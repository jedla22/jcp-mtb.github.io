---
raceid: waldkirchen
name: Waldkirchen
date: 29.4.2018
day: Neděle
place: Waldkirchend
organizator_name: RSC Waldkirchen
organizator_url: http://rscwaldkirchen.de/	
organizator_email: info@rscwaldkirchen.de
race_director: Berthold Rauch
race_director_phone: (0176) 435 199 28
race_director_email: info@rscwaldkirchen.de
#chief_commisaire: nil
#course_director: nil
#medical_assistantce: nil
#race_id: nil 
registration_link: https://docs.google.com/forms/d/e/1FAIpQLSd-hvuV11H2hf0EogEgmfS3ggtv-NqQ7hFz4XG7-nXW8KrDgA/viewform
results_link: http://www.timebike.de/SPK-MTB/Ergebnisse/2018/Spk-CupWk-Ergebnisse2018.pdf
image_url: "assets/img/waldkirchen-promo.jpg"
square_image_url: "assets/img/waldkirchen-promo-square.png"
propositions_url: http://www.timebike.de/SPK-MTB/Waldkichen/Ausschreibung%20Sparkassencup%202018.pdf
# sportsoft_timekeeping: true
---

První závod Šumavského poháru MTB 2018. Závod je součástí partnerského seriálu [Sparkassen MTB Cup](http://www.spk-mtb.de/). Závodí se podle pravidel seriálu *Sparkassen MTB Cup*, viz propozice.
